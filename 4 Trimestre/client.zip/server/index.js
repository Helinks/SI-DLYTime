const express = require("express");
const app = express();
const mysql = require("mysql");
const cors = require("cors");
const bcryptjs = require("bcryptjs");

/* Esto es de prueba de la api */
const nodemailer = require("nodemailer");
/* asta aqui */

app.use(cors());
app.use(express.json()); /*Se transforma los datos a json*/

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "dlytime",
});

/* Crud Empleados */

/*Función para registrar los Usuarios */
app.post("/registro", async (req, res) => {
    const numeroDocumento = req.body.numeroDocumento;
    const idRol = req.body.idRol;
    const idTipoIdentificacion = req.body.idTipoIdentificacion;
    const Nombres = req.body.nombre;
    const Apellidos = req.body.apellido;
    const idGenero = req.body.idGenero;
    const correo = req.body.correo;
    const clave = req.body.clave;
    const estado = false;

    /*Encriptación de contraseña al momento de guardarlo en la base de datos (método bcryptjs)*/
    try {
        const hashedPassword = await bcryptjs.hash(clave, 10);
        // Guardar el usuario en la base de datos
        db.query(
            "INSERT INTO persona (numeroDocumento, idRol, idTipoIdentificacion, Nombres, Apellidos, idGenero, correo, clave, estadoPersona) VALUES (?,?,?,?,?,?,?,?,?)",
            [
                numeroDocumento,
                idRol,
                idTipoIdentificacion,
                Nombres,
                Apellidos,
                idGenero,
                correo,
                hashedPassword,
                estado,
            ], // Usamos hashedPassword en lugar de clave
            (err, result) => {
                if (err) {
                    return res.status(500).send("Error al registrar el empleado");
                } else {
                    res.send("Empleado Registrado con éxito!!");
                }
            }
        );
    } catch (error) {
        res.status(500).send("Error al encriptar la contraseña");
    }
});

/* Validar Ingreso de Iniciar sesión  */
app.post("/login", async (req, res) => {
    const correo = req.body.correo_i;
    db.query(
        "SELECT clave FROM persona WHERE correo = ?",
        [correo],
        async (err, result) => {
            if (err) {
                return res.status(500).send("Error en la consulta de la base de datos");
            }

            if (result.length > 0) {
                const hashedPassword = result[0].clave;
                const isPasswordValid = await bcryptjs.compare(
                    req.body.password_i,
                    hashedPassword
                );
                if (isPasswordValid) {
                    app.get("/login/rol", (req, res) => {
                        db.query(
                            "SELECT idRol FROM persona WHERE correo = ?",
                            [correo],
                            (err, result) => {
                                res.send(result);
                            }
                        );
                    });
                    res.send(true);
                } else {
                    res.status(401).json({ message: "Correo o Contraseña incorrecta" });
                }
            } else {
                res.status(404).json({ message: "Correo o Contraseña incorrecta" });
            }
        }
    );
});

/* Crud Empleados */
/* Consulta los Usuarios que son empleados  */
app.get("/crud_empleados_referencia", (req, res) => {
    db.query("select * from persona where idRol = 2", (err, result) => {
        if (err) {
            console.log(err);
        } else {
            res.send(result);
        }
    });
});

/* Agregar Nuevos empleados */
app.post("/Crud_empleado_Registrar", async (req, res) => {
    const numeroDocumento = req.body.numeroDocumento;
    const idRol = req.body.idRol;
    const idTipoIdentificacion = req.body.idTipoIdentificacion;
    const Nombres = req.body.nombre;
    const Apellidos = req.body.apellido;
    const idGenero = req.body.idGenero;
    const correo = req.body.correo;
    const clave = req.body.clave;
    const telefono = req.body.telefono;
    const estado = req.body.estadoPersona;

    try {
        const hashedPassword = await bcryptjs.hash(clave, 10);
        // Guardar el usuario en la base de datos
        db.query(
            "INSERT INTO persona (numeroDocumento, idRol, idTipoIdentificacion, Nombres, Apellidos, idGenero, correo, telefono , clave, estadoPersona) VALUES (?,?,?,?,?,?,?,?,?,?)",
            [
                numeroDocumento,
                idRol,
                idTipoIdentificacion,
                Nombres,
                Apellidos,
                idGenero,
                correo,
                telefono,
                hashedPassword,
                estado,
            ], // Usamos hashedPassword en lugar de clave
            (err, result) => {
                if (err) {
                    return res.status(500).send("Error al registrar el empleado");
                } else {
                    res.send("Empleado Registrado con éxito!!");
                }
            }
        );
    } catch (error) {
        res.status(500).send("Error al encriptar la contraseña");
    }
});

/* Actualizar Empleado */
app.patch("/ActualizarEmpleado", async (req, res) => {
    const numeroDocumento = req.body.numeroDocumento;
    const idTipoIdentificacion = req.body.idTipoIdentificacion;
    const nombres = req.body.nombre;
    const apellidos = req.body.apellido;
    const idGenero = req.body.idGenero;
    const correo = req.body.correo;
    const telefono = req.body.telefono;
    const estado = req.body.estadoPersona;

    console.log("funciona");

    db.query(
        "UPDATE persona SET idTipoIdentificacion = ?, Nombres = ?, Apellidos = ?, idGenero = ?, correo = ?, telefono = ?, estadoPersona = ? WHERE numeroDocumento = ? ",
        [
            idTipoIdentificacion,
            nombres,
            apellidos,
            idGenero,
            correo,
            telefono,
            estado,
            numeroDocumento,
        ],
        (err, result) => {
            if (err) {
                console.error(err);
                res.status(500).send({ error: "Error al actualizar el empleado" });
            } else {
                res.send(result);
            }
        }
    );
});

/* Fin del Crud Empleados */

/* Crud CLientes */

app.get("/crud_clientes_referencia", (req, res) => {
    db.query("SELECT * FROM persona WHERE idRol = 1", (err, result) => {
        if (err) {
            console.error("Error al obtener los datos:", err);
            res.status(500).send("Error al obtener los datos");
            return;
        }
        res.send(result);
    });
});

app.post("/agregar_cliente", (req, res) => {
    const {
        numeroDocumento,
        idTipoIdentificacion,
        Nombres,
        Apellidos,
        correo,
        telefono,
        idGenero,
    } = req.body;
    const idRol = 1;

    db.query(
        "INSERT INTO persona (numeroDocumento, idRol, idTipoIdentificacion, Nombres, Apellidos, idGenero, correo, telefono) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        [
            numeroDocumento,
            idRol,
            idTipoIdentificacion,
            Nombres,
            Apellidos,
            idGenero,
            correo,
            telefono,
        ],
        (err, result) => {
            if (err) {
                console.error("Error al añadir el cliente:", err);
                return res.status(500).send("Error al añadir el cliente");
            } else {
                res.send("Cliente añadido con éxito");
            }
        }
    );
});

app.delete("/eliminar_cliente", (req, res) => {
    const { numeroDocumento, idTipoIdentificacion } = req.body;
    const sql =
        "DELETE FROM persona WHERE numeroDocumento = ? AND idTipoIdentificacion = ?";
    db.query(sql, [numeroDocumento, idTipoIdentificacion], (err, result) => {
        if (err) {
            console.error("Error al eliminar el cliente:", err);
            return res.status(500).send("Error al eliminar el cliente");
        }
        res.send("Cliente eliminado con éxito");
    });
});

app.put("/editar_cliente", (req, res) => {
    const {
        numeroDocumento,
        idTipoIdentificacion,
        Nombres,
        Apellidos,
        correo,
        telefono,
    } = req.body;
    const sql =
        "UPDATE persona SET Nombres = ?, Apellidos = ?, correo = ?, telefono = ? WHERE numeroDocumento = ? AND idTipoIdentificacion = ?";
    db.query(
        sql,
        [
            Nombres,
            Apellidos,
            correo,
            telefono,
            numeroDocumento,
            idTipoIdentificacion,
        ],
        (err, result) => {
            if (err) {
                console.error("Error al actualizar el cliente:", err);
                res.status(500).send("Error al editar el cliente");
            } else {
                res.send("Cliente editado con éxito");
            }
        }
    );
});

/* Fin Del crud Clientes */

/* Prueba de Api de enviar correos */

const transporter = nodemailer.createTransport({
    service: "gmail", // Cambia según tu proveedor (Gmail, Yahoo, Outlook, etc.)
    auth: {
        user: "dlytime987@gmail.com", // Cambia esto por tu correo
        pass: "cvqn rxuh gkif quww", // Cambia esto por tu contraseña
    },
});

app.post("/Enviar-correo", (req, res) => {
    const { to, subject, text } = req.body;
    const mailOptions = {
        from: "dlytime987@gmail.com",
        to, // Dirección proporcionada por el usuario
        subject, // Asunto del correo
        text, // Contenido del correo
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error(error);
            console.log(mailOptions);
            return res.status(500).send("Error enviando el correo");
        }
        res.status(200).send("Correo enviado con éxito");
    });
});

app.patch("/Cambiar-Password", async (req, res) => {
    const correo = "sebitas@gmail.com";
    const tokenCreado = 2414123;
    const tokenIngresado = 2414123;

    if (tokenIngresado == tokenCreado) {

        const hashedPassword = await bcryptjs.hash(tokenCreado, 10);
        db.query(
            "UPDATE persona SET clave = ? WHERE correo = ?",
            [hashedPassword, correo ],
            (err, result) => {
                if (err) {
                    return res.status(500).send("Error al Activar contraseña temporal");
                } else {
                    res.send("Contraseña temporal activada!!");
                }
            }
        );
    }
    else {
        res.send("Correo erroneo!!");
    };

});

/* Fin de la Prueba de enviar correos  */


function token(){
    
}

app.listen(3001, () => {
    console.log("Puerto en funcionamiento 3001");
});
