import React, { useState } from 'react';
import axios from 'axios';

function ForgotPassword() {
    const [email, setEmail] = useState('');
    const [message, setMessage] = useState('');
    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:3001/Enviar-correo', {
                to: email,
                subject: 'Restablecimiento de Contraseña',
                text: `Hola, has solicitado restablecer tu contraseña. Contáctanos si necesitas más ayuda.`,
            });
            setMessage('Correo enviado con éxito.');
        } catch (error) {
            setMessage('Hubo un error enviando el correo.');
        }
    };

    return (
        <div>
            <h4>Recuperar Contraseña</h4>
            <form onSubmit={handleSubmit}>
                <input
                    type="email"
                    placeholder="Ingresa tu correo"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />
                <button type="submit">Enviar</button>
            </form>
            {message && <p>{message}</p>}
        </div>
    );
}

export default ForgotPassword;