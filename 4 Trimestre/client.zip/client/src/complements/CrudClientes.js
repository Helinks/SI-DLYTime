import React, { useState, useEffect } from 'react';
import Axios from 'axios';
import './Css/StyleAdminClientes.css';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';

function Crud_clientes() {
  const [CrudClient, SetcrudClient] = useState([]);
  const [nuevoCliente, setNuevoCliente] = useState({
    numeroDocumento: '',
    idTipoIdentificacion: '',
    Nombres: '',
    Apellidos: '',
    correo: '',
    telefono: '',
    idGenero: ''
  });

  const [clienteEditado, setClienteEditado] = useState({
    numeroDocumento: '',
    idTipoIdentificacion: '',
    Nombres: '',
    Apellidos: '',
    correo: '',
    telefono: '',
    idGenero: ''
  });

  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);

  useEffect(() => {
    getClientes();
  }, []);

  const getClientes = () => {
    Axios.get("http://localhost:3001/crud_clientes_referencia")
      .then((response) => {
        console.log("Datos obtenidos:", response.data);
        SetcrudClient(response.data);
      })
      .catch((error) => {
        console.error("Error fetching clients:", error);
      });
  };

  const añadirCliente = () => {
    Axios.post("http://localhost:3001/agregar_cliente", nuevoCliente)
      .then(() => {
        alert("Cliente añadido con éxito");
        getClientes();
        setNuevoCliente({
          numeroDocumento: '',
          idTipoIdentificacion: '',
          Nombres: '',
          Apellidos: '',
          correo: '',
          telefono: '',
          idGenero: ''
        });
        setShowAddModal(false);
      })
      .catch((error) => {
        console.error("Error adding client:", error);
        alert("Error al añadir cliente. Verifique los datos.");
      });
  };

  const eliminarCliente = (numeroDocumento, idTipoIdentificacion) => {
    Axios.delete("http://localhost:3001/eliminar_cliente", {
      data: { numeroDocumento, idTipoIdentificacion },
    })
      .then(() => {
        alert("Cliente eliminado con éxito");
        getClientes();
      })
      .catch((error) => {
        console.error("Error deleting client:", error);
        alert("Error al eliminar cliente. Verifique los datos.");
      });
  };

  const guardarEdicion = () => {
    Axios.put("http://localhost:3001/editar_cliente", clienteEditado)
      .then(() => {
        alert("Cliente editado con éxito");
        getClientes();
        setClienteEditado({
          numeroDocumento: '',
          idTipoIdentificacion: '',
          Nombres: '',
          Apellidos: '',
          correo: '',
          telefono: '',
          idGenero: ''
        });
        setShowEditModal(false);
      })
      .catch((error) => {
        console.error("Error editing client:", error);
        alert("Error al editar cliente. Verifique los datos.");
      });
  };

  const editarCliente = (cliente) => {
    setClienteEditado(cliente);
    setShowEditModal(true);
  };

  return (
    <div>
      <h1>Gestión de Clientes</h1>

      <button className='btn1' onClick={() => setShowAddModal(true)}>
        Añadir Cliente
      </button>

      {/* Modal para Añadir Cliente */}
      <Modal show={showAddModal} onHide={() => setShowAddModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Añadir Cliente</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="formBasicNumeroDocumento">
              <Form.Label>Número de Documento</Form.Label>
              <Form.Control
                type="text"
                placeholder="Ingrese número de documento"
                value={nuevoCliente.numeroDocumento}
                onChange={(e) => setNuevoCliente({ ...nuevoCliente, numeroDocumento: e.target.value })}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicTipoIdentificacion">
              <Form.Label>Tipo Identificación</Form.Label>
              <Form.Control
                type="text"
                placeholder="Ingrese tipo de identificación"
                value={nuevoCliente.idTipoIdentificacion}
                onChange={(e) => setNuevoCliente({ ...nuevoCliente, idTipoIdentificacion: e.target.value })}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicNombres">
              <Form.Label>Nombres</Form.Label>
              <Form.Control
                type="text"
                placeholder="Ingrese nombres"
                value={nuevoCliente.Nombres}
                onChange={(e) => setNuevoCliente({ ...nuevoCliente, Nombres: e.target.value })}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicApellidos">
              <Form.Label>Apellidos</Form.Label>
              <Form.Control
                type="text"
                placeholder="Ingrese apellidos"
                value={nuevoCliente.Apellidos}
                onChange={(e) => setNuevoCliente({ ...nuevoCliente, Apellidos: e.target.value })}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicCorreo">
              <Form.Label>Correo</Form.Label>
              <Form.Control
                type="email"
                placeholder="Ingrese correo"
                value={nuevoCliente.correo}
                onChange={(e) => setNuevoCliente({ ...nuevoCliente, correo: e.target.value })}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicTelefono">
              <Form.Label>Teléfono</Form.Label>
              <Form.Control
                type="text"
                placeholder="Ingrese teléfono"
                value={nuevoCliente.telefono}
                onChange={(e) => setNuevoCliente({ ...nuevoCliente, telefono: e.target.value })}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicIdGenero">
              <Form.Label>ID Género</Form.Label>
              <Form.Control
                type="text"
                placeholder="Ingrese ID de género"
                value={nuevoCliente.idGenero}
                onChange={(e) => setNuevoCliente({ ...nuevoCliente, idGenero: e.target.value })}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <button className='btn1' onClick={() => setShowAddModal(false)}>
            Cerrar
          </button>
          <button className='btn2' onClick={añadirCliente}>
            Añadir
          </button>
        </Modal.Footer>
      </Modal>

      {/* Modal para Editar Cliente */}
      <Modal show={showEditModal} onHide={() => setShowEditModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Editar Cliente</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="formBasicNombres">
              <Form.Label>Nombres</Form.Label>
              <Form.Control
                type="text"
                placeholder="Ingrese nombres"
                value={clienteEditado.Nombres}
                onChange={(e) => setClienteEditado({ ...clienteEditado, Nombres: e.target.value })}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicApellidos">
              <Form.Label>Apellidos</Form.Label>
              <Form.Control
                type="text"
                placeholder="Ingrese apellidos"
                value={clienteEditado.Apellidos}
                onChange={(e) => setClienteEditado({ ...clienteEditado, Apellidos: e.target.value })}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicCorreo">
              <Form.Label>Correo</Form.Label>
              <Form.Control
                type="email"
                placeholder="Ingrese correo"
                value={clienteEditado.correo}
                onChange={(e) => setClienteEditado({ ...clienteEditado, correo: e.target.value })}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicTelefono">
              <Form.Label>Teléfono</Form.Label>
              <Form.Control
                type="text"
                placeholder="Ingrese teléfono"
                value={clienteEditado.telefono}
                onChange={(e) => setClienteEditado({ ...clienteEditado, telefono: e.target.value })}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicIdGenero">
              <Form.Label>ID Género</Form.Label>
              <Form.Control
                type="text"
                placeholder="Ingrese ID de género"
                value={clienteEditado.idGenero}
                onChange={(e) => setClienteEditado({ ...clienteEditado, idGenero: e.target.value })}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <button className='btn1' onClick={() => setShowEditModal(false)}>
            Cancelar
          </button>
          <button className='btn2' onClick={guardarEdicion}>
            Guardar
          </button>
        </Modal.Footer>
      </Modal>

      <table>
        <thead>
          <tr>
            <th>Número Documento</th>
            <th>Tipo Identificación</th>
            <th>Nombres</th>
            <th>Apellidos</th>
            <th>Correo</th>
            <th>Teléfono</th>
            <th>ID Género</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {CrudClient.map((cliente) => (
            <tr key={cliente.numeroDocumento}>
              <td>{cliente.numeroDocumento}</td>
              <td>{cliente.idTipoIdentificacion}</td>
              <td>{cliente.Nombres}</td>
              <td>{cliente.Apellidos}</td>
              <td>{cliente.correo}</td>
              <td>{cliente.telefono}</td>
              <td>{cliente.idGenero}</td>
              <td>
                <button className='btn1' onClick={() => editarCliente(cliente)}>
                  Editar
                </button>
                <button className='btn2' onClick={() => eliminarCliente(cliente.numeroDocumento, cliente.idTipoIdentificacion)}>
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Crud_clientes;
