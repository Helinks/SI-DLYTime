const mysql = require('mysql');

const db = mysql.createConnection({
  host: 'localhost',           // o tu IP si es remota
  user: 'root',                // cambia si tienes otro usuario
  password: '',                // cambia si tienes clave
  database: 'dlytime'         // cambia al nombre de tu base
});

db.connect((err) => {
  if (err) throw err;
  console.log(' Conectado a MySQL');
});

module.exports = db;