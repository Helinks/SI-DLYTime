const express = require('express');
const cors = require('cors');
const db = require('./db');

const app = express();

app.use(cors());
app.use(express.json()); // Para leer JSON en peticiones

// RUTA: obtener personas

app.get('/personas', (req, res) => {
    const sql = 'SELECT * FROM persona';
    db.query(sql, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

app.post('/personasRegistro', (req, res) => {
    const {
        numeroDocumento,
        idTipoIdentificacion,
        Nombres,
        Apellidos,
        idGenero,
        correo,
        clave,
        idEstadoPersona
    } = req.body;

    const sql = `
        INSERT INTO persona (
          numeroDocumento,
          idRol,
          idTipoIdentificacion,
          Nombres,
          Apellidos,
          idGenero,
          correo,
          clave,
          idEstadoPersona
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

    const values = [
        numeroDocumento,
        1,
        idTipoIdentificacion,
        Nombres,
        Apellidos,
        idGenero,
        correo,
        clave,
        idEstadoPersona
    ];

    db.query(sql, values, (err, results) => {
        if (err) {
            console.error('Error al insertar persona:', err);
            return res.status(500).send('Error al registrar persona');
        }
        console.log('Persona registrada exitosamente')
        res.status(200).json({ mensaje: 'Persona registrada exitosamente', results });
    });
});

/* Actualizar Empleado */
app.patch("/actualizarUsuario", async (req, res) => {

    console.log('si entra');

    const {
        numeroDocumento,
        idTipoIdentificacion,
        Nombres,
        Apellidos,
        idGenero,
        correo,
        telefono,
        idEstadoPersona } = req.body;

    const sql = `
        UPDATE persona SET 
        idTipoIdentificacion = ?, 
        Nombres = ?, 
        Apellidos = ?, 
        idGenero = ?, 
        correo = ?, 
        telefono = ?, 
        idEstadoPersona = ?
        WHERE numeroDocumento = ? 
      `;

    const values = [
        idTipoIdentificacion,
        Nombres,
        Apellidos,
        idGenero,
        correo,
        telefono,
        idEstadoPersona,
        numeroDocumento
    ];

    db.query(sql, values, (err, results) => {
        if (err) {
            console.error('Error al Actualizar una persona:', err);
            return res.status(500).send('Error al registrar persona');
        }
        console.log('Actualizado exitosamente')
        res.status(200).json({ mensaje: 'Persona registrada exitosamente', results });
    });
});

// Levanta el servidor
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
});