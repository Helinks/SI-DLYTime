import { Text, TextInput, View, Button, ScrollView, TouchableOpacity, Modal } from 'react-native';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Styles from './src/css/Styles';

const URL = 'http://192.168.20.26:3000';

export default function App() {
  const [modalVisible, setModalVisible] = useState(false);
  const [modalVisible2, setModalVisible2] = useState(false);

  const [personas, setPersonas] = useState<Persona[]>([]);
  const [personaSeleccionada, setPersonaSeleccionada] = useState<Persona | null>(null);

  const [busqueda, setBusqueda] = useState('');

  type Persona = {
    numeroDocumento: number;
    idTipoIdentificacion: number;
    Nombres: string;
    Apellidos: string;
    idGenero: number;
    correo: string;
    telefono: number;
    clave: string;
    idEstadoPersona: number;

  };

  const cargarPersona = () => {
    axios.get(URL + '/personas')
      .then(response => {
        setPersonas(response.data);
      })
      .catch(error => {
        console.log(error);
      });
  }

  const personasFiltradas = personas.filter((persona) =>
    persona.Nombres.toLowerCase().includes(busqueda.toLowerCase()) ||
    persona.Apellidos.toLowerCase().includes(busqueda.toLowerCase()) ||
    persona.numeroDocumento.toString().includes(busqueda)
  );



  useEffect(() => {
    cargarPersona();
  }, []);


  return (

    <View style={Styles.container}>
      <View style={Styles.topBar}>
        <TextInput
          style={Styles.input}
          placeholder="Buscar..."
          value={busqueda}
          onChangeText={(texto) => setBusqueda(texto)}
        />
        <TouchableOpacity style={Styles.botones} onPress={() => {
          setPersonaSeleccionada({
            numeroDocumento: 0,
            idTipoIdentificacion: 0,
            Nombres: '',
            Apellidos: '',
            idGenero: 0,
            correo: '',
            telefono: 0,
            clave: '',
            idEstadoPersona: 0,
          });
          setModalVisible(true);
        }}><Text style={Styles.encabezado}>ADD</Text></TouchableOpacity>
      </View>
      <View >
        <ScrollView style={Styles.tabla}>
          <View style={Styles.fila}>
            <Text style={[Styles.celda, Styles.encabezado]}>N° Documento</Text>
            <Text style={[Styles.celda, Styles.encabezado]}>Nombre</Text>
          </View>

          {personasFiltradas.map((item, index) => (
            <View key={index} style={Styles.fila}>
              <TouchableOpacity style={Styles.celda} onPress={() => {
                setPersonaSeleccionada(item);
                setModalVisible2(true);
              }}>
                <Text style={Styles.textoCelda}>{item.numeroDocumento}</Text>
              </TouchableOpacity>

              <TouchableOpacity style={Styles.celda} onPress={() => {
                setPersonaSeleccionada(item);
                setModalVisible2(true);
              }}>
                <Text style={Styles.textoCelda}>{item.Nombres}</Text>
              </TouchableOpacity>
            </View>
          ))}

        </ScrollView>
      </View>

      {/* MODAL DE AGREGAR */}



      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={Styles.modalFondo}>
          <View style={Styles.modalContenido}>
            <Text style={Styles.titulo}>Agregar</Text>

            {personaSeleccionada && (
              <>
                <TextInput
                  placeholder="Número de Documento"
                  keyboardType="numeric"
                  onChangeText={(texto) => setPersonaSeleccionada({ ...personaSeleccionada, numeroDocumento: parseInt(texto) })}
                />

                <TextInput
                  placeholder="ID Tipo de Identificación"
                  keyboardType="numeric"
                  onChangeText={(texto) => setPersonaSeleccionada({ ...personaSeleccionada, idTipoIdentificacion: parseInt(texto) })}
                />

                <TextInput
                  placeholder="Nombres"
                  onChangeText={(texto) => setPersonaSeleccionada({ ...personaSeleccionada, Nombres: texto })}
                />

                <TextInput
                  placeholder="Apellidos"
                  onChangeText={(texto) => setPersonaSeleccionada({ ...personaSeleccionada, Apellidos: texto })}
                />

                <TextInput
                  placeholder="ID Género"
                  keyboardType="numeric"
                  onChangeText={(texto) => setPersonaSeleccionada({ ...personaSeleccionada, idGenero: parseInt(texto) })}
                />

                <TextInput
                  placeholder="Correo Electrónico"
                  onChangeText={(texto) => setPersonaSeleccionada({ ...personaSeleccionada, correo: texto })}
                />

                <TextInput
                  placeholder="Telefono"
                  onChangeText={(texto) => setPersonaSeleccionada({ ...personaSeleccionada, telefono: parseInt(texto) })}
                />

                <TextInput
                  placeholder="Clave"
                  secureTextEntry
                  onChangeText={(texto) => setPersonaSeleccionada({ ...personaSeleccionada, clave: texto })}
                />

                <TextInput
                  placeholder="ID Estado Persona"
                  keyboardType="numeric"
                  onChangeText={(texto) => setPersonaSeleccionada({ ...personaSeleccionada, idEstadoPersona: parseInt(texto) })}
                />
              </>
            )}
            < Button
              title="Guardar"
              onPress={() => {
                if (!personaSeleccionada) return;

                // Agregar datos
                console.log('Datos a agregar:', personaSeleccionada);
                axios.post(URL + '/personasRegistro', personaSeleccionada)
                  .then(response => {
                    console.log('Persona agregada:', response.data);
                    // Opcional: actualizar la lista
                    setPersonas(prev => [...prev, response.data]);
                    // Cerrar el modal
                    setModalVisible(false);
                    // Limpiar el formulario
                    setPersonaSeleccionada(null);

                    cargarPersona();
                  })
                  .catch(error => {
                    console.error('Error al agregar persona:', error);
                  });
                setModalVisible(false);
              }}
            />
            <Button
              title="Cancelar"
              onPress={() => {
                // Cancelar edición
                setModalVisible(false);
              }}
            />
          </View>
        </View>
      </Modal>



      {/* MODAL DE MODIFICACIÓN */}

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible2}
        onRequestClose={() => setModalVisible2(false)}
      >
        <View style={Styles.modalFondo}>
          <View style={Styles.modalContenido}>
            <Text style={Styles.titulo}>Editar</Text>

            {personaSeleccionada && (
              <>
                <TextInput
                  value={personaSeleccionada.Nombres}
                  placeholder="Nombres"
                  onChangeText={(texto) =>
                    setPersonaSeleccionada({
                      ...personaSeleccionada,
                      Nombres: texto,
                    })
                  }
                />

                <TextInput
                  value={personaSeleccionada.Apellidos}
                  placeholder="Apellidos"
                  onChangeText={(texto) =>
                    setPersonaSeleccionada({
                      ...personaSeleccionada,
                      Apellidos: texto,
                    })
                  }
                />

                <TextInput
                  value={personaSeleccionada.numeroDocumento.toString()}
                  placeholder="Número Documento"
                  keyboardType="numeric"
                  onChangeText={(texto) =>
                    setPersonaSeleccionada({
                      ...personaSeleccionada,
                      numeroDocumento: parseInt(texto),
                    })
                  }
                />

                <TextInput
                  value={personaSeleccionada.idTipoIdentificacion.toString()}
                  placeholder="ID Tipo Identificación"
                  keyboardType="numeric"
                  onChangeText={(texto) =>
                    setPersonaSeleccionada({
                      ...personaSeleccionada,
                      idTipoIdentificacion: parseInt(texto),
                    })
                  }
                />

                <TextInput
                  value={personaSeleccionada.idGenero.toString()}
                  placeholder="ID Género"
                  keyboardType="numeric"
                  onChangeText={(texto) =>
                    setPersonaSeleccionada({
                      ...personaSeleccionada,
                      idGenero: parseInt(texto),
                    })
                  }
                />

                <TextInput
                  value={personaSeleccionada.correo}
                  placeholder="Correo"
                  onChangeText={(texto) =>
                    setPersonaSeleccionada({
                      ...personaSeleccionada,
                      correo: texto,
                    })
                  }
                />

                <TextInput
                  value={personaSeleccionada.clave}
                  placeholder="Clave"
                  secureTextEntry
                  onChangeText={(texto) =>
                    setPersonaSeleccionada({
                      ...personaSeleccionada,
                      clave: texto,
                    })
                  }
                />

                <TextInput
                  value={personaSeleccionada.idEstadoPersona.toString()}
                  placeholder="ID Estado Persona"
                  keyboardType="numeric"
                  onChangeText={(texto) =>
                    setPersonaSeleccionada({
                      ...personaSeleccionada,
                      idEstadoPersona: parseInt(texto),
                    })
                  }
                />
              </>
            )}

            <Button
              title="Guardar"
              onPress={() => {

                // Actualizar dato
                axios.patch(URL + '/actualizarUsuario', personaSeleccionada)
                  .then(response => {
                    console.log('Persona actualizada:', response.data);
                    // Cerrar el modal
                    setModalVisible(false);
                    // Limpiar el formulario
                    setPersonaSeleccionada(null);

                    cargarPersona();

                    console.log('Datos a actualizar:', personaSeleccionada);
                    setModalVisible2(false);
                  })


              }}
            />
            <Button
              title="Cancelar"
              onPress={() => {
                // Cancelar edición
                setModalVisible2(false);
              }}
            />
          </View>
        </View>
      </Modal>

    </View>


  );
}


