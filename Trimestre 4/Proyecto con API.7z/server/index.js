const express = require("express");
const app = express();
const mysql = require("mysql")
const cors = require("cors");

app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"dlytime"
})

app.post("/create",(req,res)=>{
    const numeroDocumento = req.body.numeroDocumento
    const idRol = req.body.idRol
    const idTipoIdentificacion = req.body.idTipoIdentificacion
    const primerNombre = req.body.primerNombre
    const segundoNombre = req.body.segundoNombre
    const primerApellido = req.body.primerApellido
    const segundoApellido = req.body.segundoApellido
    const idGenero = req.body.idGenero
    const correo = req.body.correo
    const telefono = req.body.telefono
    const clave = req.body.clave
    const fechaNacimiento = req.body.fechaNacimiento
    const direccion = req.body.direccion

    db.query('INSERT INTO persona (numeroDocumento, idRol, idTipoIdentificacion, primerNombre, segundoNombre, primerApellido, segundoApellido, idGenero, correo, telefono, clave, fechaNacimiento, direccion) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',[numeroDocumento, idRol, idTipoIdentificacion, primerNombre, segundoNombre, primerApellido, segundoApellido, idGenero, correo, telefono, clave, fechaNacimiento, direccion],
    (err,result)=>{
        if(err){
            console.log(err);
        }else{
            res.send("Empleado Registrado con éxito!!");
        }
    })

});

app.listen(3001,()=>{
    console.log("Puerto en funcionamiento 3001");
})