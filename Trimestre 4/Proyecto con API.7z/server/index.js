const express = require("express");
const app = express();
const mysql = require("mysql")
const cors = require("cors");
const bcryptjs = require("bcryptjs");



app.use(cors());
app.use(express.json());/*Se transforma los datos a json*/

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "dlytime"
})

/*Ruta o método para la ejecución del registro de un usuario con sus datos necesarios*/
app.post("/registro", async (req, res) => {
    const numeroDocumento = req.body.numeroDocumento
    const idRol = req.body.idRol
    const idTipoIdentificacion = req.body.idTipoIdentificacion
    const Nombres = req.body.nombre
    const Apellidos = req.body.apellido
    const idGenero = req.body.idGenero
    const correo = req.body.correo
    const clave = req.body.clave
    const estado = false

    /*Encriptación de contraseña al momento de guardarlo en la base de datos (método bcryptjs)*/
    try {
        const hashedPassword = await bcryptjs.hash(clave, 10);
        // Guardar el usuario en la base de datos con la contraseña encriptada
        db.query('INSERT INTO persona (numeroDocumento, idRol, idTipoIdentificacion, Nombres, Apellidos, idGenero, correo, clave, estadoPersona) VALUES (?,?,?,?,?,?,?,?,?)',
            [numeroDocumento, idRol, idTipoIdentificacion, Nombres, Apellidos, idGenero, correo, hashedPassword, estado],  // Usamos hashedPassword en lugar de clave
            (err, result) => {

                if (err) {/* Validación de ejecución del registro*/
                    return res.status(500).send("Error al registrar el empleado");
                } else {
                    res.send("Empleado Registrado con éxito!!");
                }

            });
    } catch (error) {
        res.status(500).send("Error al encriptar la contraseña");
    }
});

/* Ruta o método para realizar el login */
app.post("/login", async (req, res) => {
    const correo = req.body.correo_i

    /* Consulta para obtener la clave del correo digitado por el usuario */
    db.query('SELECT clave FROM persona WHERE correo = ?', [correo],
        async (err, result) => {
            if (err) {
                return res.status(500).send("Error en la consulta de la base de datos");
            }
            if (result.length > 0) {/* Si el correo es existente realizarala la validación de password */

                /*Validación de contraseña con el correo correspondiente*/
                const hashedPassword = result[0].clave;
                const isPasswordValid = await bcryptjs.compare(req.body.password_i, hashedPassword);
                if (isPasswordValid) {
                    app.get("/login/rol", (req, res) => {
                        db.query('SELECT idRol FROM persona WHERE correo = ?', [correo], (err, result) => {
                            res.send(result);
                        })
                    });
                    res.send(true);
                } else {
                    res.status(401).json({ message: "Correo o Contraseña incorrecta" });
                }
            } else {
                res.status(404).json({ message: "Correo o Contraseña incorrecta" });
            }

        });
});

app.get("/crud_empleados_referencia", (req, res) => { 
    db.query("select * from persona where idRol = 2",
        (err, result) => {
            if (err) {
                console.log(err);
            } else {
                res.send(result);
            }
        }

    )
})




app.listen(3001, () => {
    console.log("Puerto en funcionamiento 3001");
})
