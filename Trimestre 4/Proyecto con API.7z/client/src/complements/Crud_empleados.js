import React, { useState } from 'react';
import  Axios  from 'axios';

function Crud_empleados  () {

  
  const [CrudEmple, SetcrudEmple] = useState([]);
  
  const getEmpleados = () => {

    Axios.get("http://localhost:3001/crud_empleados_referencia").then((empleados) => {
      SetcrudEmple(empleados.data);
    })
  }


  getEmpleados()
  return (<div>
    <table className="table table-striped">
      <thead>
        <tr>
          <th scope='row'>Documento</th>
          <th>TipoIdentificacion</th>
          <th>Nombre</th>
          <th>Apellido</th>
          <th>Genero</th>
          <th>Correo</th>
          <th>Telefono</th>
        </tr>
      </thead>
      <tbody>
        {
          CrudEmple.map((val,key) => {
            return <tr>
              <th scope='row'>{val.numeroDocumento}</th>
              <td>{val.idTipoIdentificacion}</td>
              <td>{val.primerNombre}</td>
              <td>{val.primerApellido}</td>
              <td>{val.idGenero}</td>
              <td>{val.Correo}</td>
              <td>{val.telefono}</td>
            </tr>

          })
        }
      </tbody>
    </table>
  </div>
  )

}

export default Crud_empleados