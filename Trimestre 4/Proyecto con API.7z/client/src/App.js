import './App.css';
import { useState } from 'react';
import Axios from "axios";




function App() {

  const [numeroDocumento,setnumeroDocumento] = useState("1013110701");
  const [idRol,setidRol] = useState("1");
  const [idTipoIdentificacion,setidTipoIdentificacion] = useState("2");
  const [primerNombre,setprimerNombre] = useState("Jose");
  const [segundoNombre,setsegundoNombre] = useState("Maria");
  const [primerApellido,setprimerApellido] = useState("Rodriguez");
  const [segundoApellido,setsegundoApellido] = useState("Vasquez");
  const [idGenero,setidGenero] = useState("2");
  const [correo,setcorreo] = useState("seb@gmail.com");
  const [telefono,settelefono] = useState("32415");
  const [clave,setclave] = useState("123");
  const [fechaNacimiento,setfechaNacimiento] = useState("2000-05-20");
  const [direccion,setdireccion] = useState("calle 3");

  const add = (e)=> {
    e.preventDefault();
    Axios.post("http://localhost:3001/create",{


    numeroDocumento:numeroDocumento,
    idRol:idRol,
    idTipoIdentificacion:idTipoIdentificacion,
    primerNombre:primerNombre,
    segundoNombre:segundoNombre,
    primerApellido:primerApellido,
    segundoApellido:segundoApellido,
    idGenero:idGenero,
    correo:correo,
    telefono:telefono,
    clave:clave,
    fechaNacimiento:fechaNacimiento,
    direccion:direccion
    }).then(()=>{
      alert("Empleado Registrado")
    })
  }

  return (
    <div>
      <center>
      <form className ="App">
        <input 
          id="numeroDocumento" 
          value={numeroDocumento} 
          onChange={(e) => setnumeroDocumento(e.target.value)} 
          placeholder="Número de Documento" 
        />
        <input 
          id="idRol" 
          value={idRol} 
          onChange={(e) => setidRol(e.target.value)} 
          placeholder="ID Rol" 
        />
        <input 
          id="idTipoIdentificacion" 
          value={idTipoIdentificacion} 
          onChange={(e) => setidTipoIdentificacion(e.target.value)} 
          placeholder="ID Tipo Identificación" 
        />
        <input 
          id="primerNombre" 
          value={primerNombre} 
          onChange={(e) => setprimerNombre(e.target.value)} 
          placeholder="Primer Nombre" 
        />
        <input 
          id="segundoNombre" 
          value={segundoNombre} 
          onChange={(e) => setsegundoNombre(e.target.value)} 
          placeholder="Segundo Nombre" 
        />
        <input 
          id="primerApellido" 
          value={primerApellido} 
          onChange={(e) => setprimerApellido(e.target.value)} 
          placeholder="Primer Apellido" 
        />
        <input 
          id="segundoApellido" 
          value={segundoApellido} 
          onChange={(e) => setsegundoApellido(e.target.value)} 
          placeholder="Segundo Apellido" 
        />
        <input 
          id="idGenero" 
          value={idGenero} 
          onChange={(e) => setidGenero(e.target.value)} 
          placeholder="ID Género" 
        />
        <input 
          id="correo" 
          value={correo} 
          onChange={(e) => setcorreo(e.target.value)} 
          placeholder="Correo" 
        />
        <input 
          id="telefono" 
          value={telefono} 
          onChange={(e) => settelefono(e.target.value)} 
          placeholder="Teléfono" 
        />
        <input 
          id="clave" 
          value={clave} 
          onChange={(e) => setclave(e.target.value)} 
          placeholder="Clave" 
        />
        <input 
          type="date"
          id="fechaNacimiento" 
          value={fechaNacimiento} 
          onChange={(e) => setfechaNacimiento(e.target.value)} 
          placeholder="Fecha de Nacimiento" 
        />
        <input 
          id="direccion" 
          value={direccion} 
          onChange={(e) => setdireccion(e.target.value)} 
          placeholder="Dirección" 
        />
        <button onClick={add}>Guardar</button>
      </form>
      </center>
    </div>
  );
}

export default App;