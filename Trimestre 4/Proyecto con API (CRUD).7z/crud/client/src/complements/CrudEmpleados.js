import React, { useState, useEffect } from 'react';
import './Css/StyleAdminClientes.css';
import Axios from 'axios';

function CrudEmpleados() {

  const [apellido, setApellidos] = useState("");
  const [nombre, setNombres] = useState("");
  const [tipodocumento, setidTipoIdentificacion] = useState("");
  const [ndocumento, setnumeroDocumento] = useState("");
  const [correo, setcorreo] = useState("");
  /* const [password, setPassword] = useState(""); */
  const [telefono, settelefono] = useState("");
  /* const [Confirmar_password, setConfirmar_password] = useState(""); */
  const [genero, setidGenero] = useState("");
  const [CrudEmple, SetcrudEmple] = useState([]);

  useEffect(() => {
    getEmpleados();
  }, []);

  const getEmpleados = () => {



    Axios.get("http://localhost:3001/crud_empleados_referencia").then((empleados) => {
      SetcrudEmple(empleados.data);
    })
  }

  const MostrarEmpleado = (val) => {
    
    setnumeroDocumento(val.numeroDocumento);
    setidTipoIdentificacion(val.idTipoIdentificacion);
    setNombres(val.Nombres);
    setApellidos(val.Apellidos);
    setidGenero(val.idGenero);
    setcorreo(val.correo);
    settelefono(val.telefono);


  }

  const editarEmpleado = () => {

    Axios.patch("http://localhost:3001/ActualizarEmpleado", {
      numeroDocumento: ndocumento,
      idRol: 2,
      idTipoIdentificacion: tipodocumento,
      nombre: nombre,
      apellido: apellido,
      idGenero: genero,
      correo: correo,
      telefono: telefono,
    }).then(() => {
      alert("Datos Guardados!");
    });
  }



  return (<div>
    <div class="container">
      <div class="input-group input-group-sm mb-3">
        <span class="input-group-text" id="inputGroup-sizing-sm" >Numero de ID</span>
        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" value={ndocumento} onChange={(e) => setnumeroDocumento(e.target.value)} />
      </div>

      <div class="input-group input-group-sm mb-3">
        <span class="input-group-text" id="inputGroup-sizing-sm" >Tipo de Identificacion</span>
        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" value={tipodocumento} onChange={(e) => setidTipoIdentificacion(e.target.value)} />
      </div>

      <div class="input-group input-group-sm mb-3">
        <span class="input-group-text" id="inputGroup-sizing-sm">Nombre</span>
        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" value={nombre} onChange={(e) => setNombres(e.target.value)} />
      </div>

      <div class="input-group input-group-sm mb-3">
        <span class="input-group-text" id="inputGroup-sizing-sm">Apellido</span>
        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" value={apellido} onChange={(e) => setApellidos(e.target.value)}/>
      </div>

      <div class="input-group input-group-sm mb-3">
        <span class="input-group-text" id="inputGroup-sizing-sm">Genero</span>
        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" value={genero} onChange={(e) => setidGenero(e.target.value)}/>
      </div>

      <div class="input-group input-group-sm mb-3">
        <span class="input-group-text" id="inputGroup-sizing-sm">Correo</span>
        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" value={correo} onChange={(e) => setcorreo(e.target.value)}/>
      </div>

      <div class="input-group input-group-sm mb-3">
        <span class="input-group-text" id="inputGroup-sizing-sm">Telefono</span>
        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm" value={telefono} onChange={(e) => settelefono(e.target.value)}/>
      </div>
    </div>

    <div class="botones-acciones">
      <button type="button" class="btn btn-outline-success" onClick={editarEmpleado}>Success</button>
    </div>
    

    <table className="table table-striped" id="TablaEmpleados">
      <thead>
        <tr>
          <th scope='row'>Documento</th>
          <th>TipoIdentificacion</th>
          <th>Nombre</th>
          <th>Apellido</th>
          <th>Genero</th>
          <th>Correo</th>
          <th>Teléfono</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        {
          CrudEmple.map((val, key) => {
            return <tr>
              <th scope='row'>{val.numeroDocumento}</th>
              <td>{val.idTipoIdentificacion}</td>
              <td>{val.Nombres}</td>
              <td>{val.Apellidos}</td>
              <td>{val.idGenero}</td>
              <td>{val.correo}</td>
              <td>{val.telefono}</td>
              <td>
                <button type="button" class="btn btn-primary" onClick={() => { MostrarEmpleado(val) }}>
                  Seleccionar
                </button>


              </td>
            </tr>

          })
        }
      </tbody>
    </table>
  </div>
  )

}

export default CrudEmpleados