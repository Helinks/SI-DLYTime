import "./Css/loginStyle.css";
import { useState } from "react";
import { Outlet, Link, useNavigate } from "react-router-dom";
import Axios from "axios";

function Login() {
  const navigate = useNavigate();

  const [correo_i, setCorreo] = useState("");
  const [password_i, setPassword] = useState("");
  const [error, setError] = useState(false);
  const [errorU, setErrorU] = useState(["", false]);

  const consulta = (e) => {
    e.preventDefault();/*Evita la recarga de pagina*/

    /*Se valida los campos si estan vacios*/
    if (correo_i === "" || password_i === "") {
      setError(true);
      return;
    }

    setError(false);
    Axios.post("http://localhost:3001/login", {
      correo_i: correo_i,
      password_i: password_i
    }).then(() => {
      // Manejar la consulta del rol
      obtenerDatos();
    }).catch((error) => {

      setErrorU([error.response.data.message, true]);  /*Evitar mostrar el mensaje de error en pantalla*/
      console.log(errorU);
    });
  };

  /*Manejo de consulta del rol para obtenerlo y validarlo*/
  const obtenerDatos = () => {
    Axios.get("http://localhost:3001/login/rol").then((respuestass) => {
      guardar(respuestass.data);
    });
  };
  async function guardar(data) {
    const rol = data[0].idRol;
    /* Verifica que usuario ingresará */
    rol === 1 ? navigate("/IndexCliente")
      : rol === 2 ? navigate("/IndexAdmin")
        : navigate("/IndexEmpleado")
  }



  return (
    /* Formulario y más.. */
    <div>
      <>
        <div
          className="body-login"
          style={{ backgroundImage: "url(img/fondo.png)" }}
        >
          <div className="contenedor-formulario">
            <div className="information">
              <div className="izquierda">
                <h2>¿No tienes una cuenta?</h2>
                <Link to="/SignIn">
                  <input type="button" value="Registrarme" id="sign-in" />
                </Link>
              </div>
            </div>
            <div className="derecha">
              <form className="form" method="POST" noValidate>
                <h1 id="Titulo">
                  <b>Iniciar Sesión</b>
                </h1>
                <div className="inputs">
                  <div className="input-group mb-3">
                    <span className="input-group-text" id="basic-addon1">
                      @
                    </span>
                    <input
                      type="email"
                      className="form-control"
                      placeholder="Correo"
                      aria-label="Username"
                      aria-describedby="basic-addon1"
                      value={correo_i}
                      onChange={(e) => setCorreo(e.target.value)}
                    />
                  </div>
                  <div className="input-group mb-3">
                    <span className="input-group-text" id="basic-addon1">
                      ⌘
                    </span>
                    <input
                      type="password"
                      className="form-control"
                      placeholder="Password"
                      aria-label="Username"
                      aria-describedby="basic-addon1"
                      value={password_i}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                </div>
              </form>
              <div className="botones-inicio">
                <button type="submit" className="iniciar" onClick={consulta}>
                  Iniciar sesión
                </button>
                <Link to="/CambiarPass">
                  <button type="button" className="olvidar" name="register">
                    Olvidaste tu contraseña
                  </button>
                </Link>

                {/* Mensaje de validación de campos llenados */}
                {error && (
                  <p className="texto-error"> Por favor, complete todos los campos.</p>
                )}
                {/* Mensaje de error de correo o contraseña incorrectos  */}
                {errorU[1] && (
                  <p className="texto-error">{errorU[0]}</p>
                )}

              </div>
            </div>
          </div>
        </div>
      </>
      <Outlet />
    </div>
  );
}

export default Login;