import Login from './complements/Login';
import SignIn from './complements/SignIn';
import Index from './complements/index';
import IndexAdmin from './complements/IndexAdmin';
import CrudEmpleados from './complements/CrudEmpleados';
import { Route, Routes } from 'react-router-dom';

function App() {
  return (

    <div className="App">
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path='/SignIn' element={<SignIn />}></Route>
        <Route path='/Login' element={<Login />}></Route>
        <Route path='/CrudEmpleados' element={<CrudEmpleados />}></Route>
        <Route path='/IndexAdmin' element={<IndexAdmin />}></Route>
        <Route path='/AdminEmpleados' element={<SignIn />}></Route>
      </Routes>
    </div>

  );
}

export default App;
