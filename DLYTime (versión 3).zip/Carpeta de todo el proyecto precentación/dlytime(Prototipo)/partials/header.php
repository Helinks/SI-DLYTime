<link rel="stylesheet" href="./css/header_style.css">
<link rel="shortcut icon" href="images/logo1.ico" />
<header class="header">

        <div class="head">
    
    <a href="index.php"><img src="imagenes/logo.png" width="60px" height="60px"></a>


    <nav class="nav"> 

        <ul>
            <div class="nav-1">
            <div>
              
            </div>
            <div class="nav-2">
              <li><a href="usuario.php"><img src="images/user.png" width="50px" height="50px"></a>
                  <ul>

                     <li><a href="logout.php">cerrar sesión</a></li>
                   
                  </ul>   
              </li>
            </div>
            </div>
        </ul>

    </nav>

</div>
    
        </header>